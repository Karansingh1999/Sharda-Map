package com.example.chooseyouroption;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;
import android.widget.ZoomControls;

public class Main6Activity extends AppCompatActivity {

    TextView textView;
    ZoomControls zoomControls_1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        textView = findViewById(R.id.textView);
        zoomControls_1 = findViewById(R.id.zoomControls_1);

        textView.setMovementMethod(new ScrollingMovementMethod());

        zoomControls_1.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = textView.getTextScaleX();

                textView.setTextScaleX((int) (x+1));
            }
        });

        zoomControls_1.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = textView.getTextScaleX();

                textView.setTextScaleX((int) (x-1));
            }
        });
    }
}
