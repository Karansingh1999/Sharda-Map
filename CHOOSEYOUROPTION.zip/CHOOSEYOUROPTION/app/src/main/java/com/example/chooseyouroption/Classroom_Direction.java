package com.example.chooseyouroption;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class Classroom_Direction extends AppCompatActivity {

    ImageView block1_class1,block1_class2,block1_class3,block1_class4,block1_class5,block1_class6,block3_class1,block3_class2,block3_class3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classroom__direction);

        block1_class1 = findViewById(R.id.block1_class1);
        block1_class2 = findViewById(R.id.block1_class2);
        block1_class3 = findViewById(R.id.block1_class3);
        block1_class4 = findViewById(R.id.block1_class4);
        block1_class5 = findViewById(R.id.block1_class5);
        block1_class6 = findViewById(R.id.block1_class6);
        block3_class1 = findViewById(R.id.block3_class1);
        block3_class2 = findViewById(R.id.block3_class2);
        block3_class3 = findViewById(R.id.block3_class3);
    }
}
