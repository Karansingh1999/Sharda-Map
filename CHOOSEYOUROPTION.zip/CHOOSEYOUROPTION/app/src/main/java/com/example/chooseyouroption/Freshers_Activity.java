package com.example.chooseyouroption;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ZoomControls;

public class Freshers_Activity extends AppCompatActivity {

    ImageView image_fresher1,image_fresher2,image_fresher3;

    ZoomControls zoomControls_3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freshers_);

        image_fresher1 = findViewById(R.id.image_fresher1);
        image_fresher2 = findViewById(R.id.image_fresher2);
        image_fresher3 = findViewById(R.id.image_fresher3);
        zoomControls_3 = findViewById(R.id.zoomControls_3);

        zoomControls_3.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = image_fresher1.getScaleX();
                float y = image_fresher1.getScaleY();

                image_fresher1.setScaleX((int) (x+1));
                image_fresher1.setScaleY((int) (y+1));
            }
        });

        zoomControls_3.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float x = image_fresher1.getScaleX();
                float y = image_fresher1.getScaleY();


                image_fresher1.setScaleX((int) (x-1));
                image_fresher1.setScaleY((int) (y-1));
            }
        });
        zoomControls_3.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = image_fresher2.getScaleX();
                float y= image_fresher2.getScaleY();

                image_fresher2.setScaleX((int) (x+1));
                image_fresher2.setScaleY((int) (y+1));
            }
        });

        zoomControls_3.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float x= image_fresher2.getScaleX();
                float y = image_fresher2.getScaleY();

                image_fresher2.setScaleX((int) (x-1));
                image_fresher2.setScaleY((int) (y-1));
            }
        });

        zoomControls_3.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float x = image_fresher3.getScaleX();
                float y = image_fresher3.getScaleY();

                image_fresher3.setScaleX((int) (x+1));
                image_fresher3.setScaleY((int) (y+1));


            }
        });

        zoomControls_3.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = image_fresher3.getScaleX();
                float y= image_fresher3.getScaleY();

                image_fresher3.setScaleX((int) (x-1));
                image_fresher3.setScaleY((int) (y-1));
            }
        });
    }
}
