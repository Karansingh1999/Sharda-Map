package com.example.chooseyouroption;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class AdmissionCell1 extends AppCompatActivity {


    ImageView image_view5;
    Button admission_button;
    ListView admission_listview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admission_cell1);


        image_view5 = findViewById(R.id.image_view5);
        admission_button=findViewById(R.id.admissionlink_button);
        admission_listview=findViewById(R.id.listview_admission);
    }
}
