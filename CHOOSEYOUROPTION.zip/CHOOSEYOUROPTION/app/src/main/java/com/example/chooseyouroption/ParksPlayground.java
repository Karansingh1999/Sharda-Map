package com.example.chooseyouroption;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ParksPlayground extends AppCompatActivity {
    ImageView basketBall,vollyGround,cricketGround;
    TextView basketball_text,vollyball_text,cricket_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parks_playground);

        basketBall = findViewById(R.id.basketBall);
        vollyGround = findViewById(R.id.vollyGround);
        cricketGround = findViewById(R.id.cricketGround);
        basketball_text = findViewById(R.id.basketball_text);
        vollyball_text = findViewById(R.id.vollyground_text);
        cricket_text = findViewById(R.id.cricket_text);
    }
}
