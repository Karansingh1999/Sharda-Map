package com.example.chooseyouroption;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class Labs_Activity extends AppCompatActivity {

    ImageView image_lab1,image_lab2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_labs_);

        image_lab1 = findViewById(R.id.image_lab1);
        image_lab2 = findViewById(R.id.image_lab2);
    }
}
